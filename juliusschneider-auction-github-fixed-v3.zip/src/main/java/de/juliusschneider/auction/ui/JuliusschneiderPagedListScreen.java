package de.juliusschneider.auction.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Basis für seitenweise Listen (Verlauf, Zahlungslog). */
public abstract class JuliusschneiderPagedListScreen extends JuliusschneiderBaseScreen {
    protected static final int ROWS = 7, ROW_H = 24;
    protected final Screen parent;
    protected int page;

    protected JuliusschneiderPagedListScreen(String title, Screen parent) {
        super(title);
        this.parent = parent;
    }

    protected abstract int size();
    protected abstract void drawRow(GuiGraphicsExtractor g, int index, int x, int y, int w);
    protected abstract String heading();
    protected String subtitle() { return ""; }
    protected String emptyText() { return "Noch keine Einträge"; }
    /** Optionaler zweiter Button neben ZURÜCK. */
    protected String extraLabel() { return null; }
    protected void onExtra() {}

    private int pages() { return Math.max(1, (size() + ROWS - 1) / ROWS); }

    @Override
    protected void build() {
        page = Math.max(0, Math.min(page, pages() - 1));
        int x = px + 14, w = pw - 28;
        btn(x, py + 236, 40, 20, "<", MUTED, page > 0, () -> { page--; rebuildWidgets(); });
        btn(x + w - 40, py + 236, 40, 20, ">", MUTED, page < pages() - 1, () -> { page++; rebuildWidgets(); });
        if (extraLabel() == null) {
            btn(x, py + ph - 46, w, 28, "ZURÜCK", GOLD, this::onClose);
        } else {
            int hw = (w - 6) / 2;
            btn(x, py + ph - 46, hw, 28, "ZURÜCK", GOLD, this::onClose);
            btn(x + hw + 6, py + ph - 46, w - hw - 6, 28, extraLabel(), BLUE, () -> { onExtra(); page = 0; rebuildWidgets(); });
        }
    }

    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        textScaled(g, heading(), px + 14, py + 12, GOLD, 1.3f);
        text(g, trim(subtitle(), pw - 28), px + 14, py + 40, MUTED);
        int n = size();
        if (n == 0) { centered(g, emptyText(), px + pw / 2, py + 120, MUTED); return; }
        for (int i = 0; i < ROWS; i++) {
            int idx = page * ROWS + i;
            if (idx >= n) break;
            drawRow(g, idx, px + 14, py + 56 + i * ROW_H, pw - 28);
        }
        centered(g, "Seite " + (page + 1) + " / " + pages(), px + pw / 2, py + 242, MUTED);
    }

    @Override
    public void onClose() { Minecraft.getInstance().setScreen(parent); }
}
