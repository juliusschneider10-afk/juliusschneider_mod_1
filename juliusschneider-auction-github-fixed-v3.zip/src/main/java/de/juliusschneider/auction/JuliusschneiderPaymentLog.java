package de.juliusschneider.auction;

import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Log aller erkannten Zahlungen (config/juliusschneider_auction_payments.json, max. 500 Einträge). */
public final class JuliusschneiderPaymentLog {
    public static class Entry {
        public long time;
        public String player = "";
        public long amount;
        public String result = "";
    }

    private static final String FILE = "juliusschneider_auction_payments.json";
    private static final int MAX = 500;
    private static List<Entry> entries = new ArrayList<>();

    private JuliusschneiderPaymentLog() {}

    public static void load() {
        entries = JuliusschneiderStorage.load(FILE, new TypeToken<List<Entry>>() {}.getType());
    }

    public static void add(String player, long amount, String result) {
        Entry e = new Entry();
        e.time = System.currentTimeMillis();
        e.player = player;
        e.amount = amount;
        e.result = result;
        entries.add(e);
        while (entries.size() > MAX) entries.remove(0);
        JuliusschneiderStorage.save(FILE, entries);
    }

    public static List<Entry> newestFirst() {
        List<Entry> c = new ArrayList<>(entries);
        Collections.reverse(c);
        return c;
    }
}
